
Future<int> delayedValue(int value) async {
  await Future.delayed(
    Duration(milliseconds: 100),
  );

  return value;
}

Future<int> sumValues(int a, int b) async {
  int firstValue = await delayedValue(a);
  int secondValue = await delayedValue(b);

  return firstValue + secondValue;
}

void main() async {
  int result = await sumValues(12, 8);

  print("Sum: $result");
}
