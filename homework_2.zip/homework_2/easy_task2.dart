
class Book {
  String title;
  String author;
  int pages;

  Book(this.title, this.author, this.pages);

  String getInfo() {
    return "$title by $author, Pages $pages";
  }
}

void main() {
  Book myBook = Book("Harry Potter", "J.K. Rowling", 350);

  print(myBook.getInfo());
}
