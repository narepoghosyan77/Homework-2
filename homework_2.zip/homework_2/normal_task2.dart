
class Product {
  String name;
  String category;
  double price;

  Product(this.name, this.category, this.price);
}

Map<String, double> totalByCategory(
    List<Product> products) {
  Map<String, double> totals = {};

  for (Product item in products) {
    if (totals.containsKey(item.category)) {
      totals[item.category] =
          totals[item.category]! + item.price;
    } else {
      totals[item.category] = item.price;
    }
  }

  return totals;
}

void main() {
  List<Product> products = [
    Product("Orange", "Fruit", 3.0),
    Product("Pear", "Fruit", 2.0),
    Product("Yogurt", "Dairy", 2.5),
    Product("Butter", "Dairy", 4.5),
    Product("Rice", "Grain", 4.0),
  ];

  Map<String, double> result =
      totalByCategory(products);

  print(result);
}
