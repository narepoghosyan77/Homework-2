void main() {
  List<String> items = ["milk", "eggs", "bread"];

  items.add("apples");
  items.insert(1, "juice");
  items.removeAt(0);
  items[1] = "cheese";

  print("First item: ${items.first}");
  print("Last item: ${items.last}");
  print("Is empty: ${items.isEmpty}");
  print("Shopping list: $items");
}